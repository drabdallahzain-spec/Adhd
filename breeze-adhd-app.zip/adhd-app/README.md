# Breeze — ADHD Daily Companion

A gentle, ADHD-aware daily companion: energy-based task lists, a HALT needs check, a single-task Focus mode with Pomodoro timer and CBT "stuck" strategies, a Brain Dump tool, a 5-prayer tracker, and an XP/streak system — all backed by Supabase so your data persists across devices.

## Tech stack

- **React 18 + Vite** — frontend
- **Tailwind CSS** — styling
- **Supabase** — Postgres database, auth, and row-level security
- **lucide-react** — icons

## 1. Create your Supabase project

1. Go to [supabase.com](https://supabase.com) → New Project (the free tier is enough).
2. Once it's created, open **SQL Editor** in the left sidebar → **New query**.
3. Open `supabase/schema.sql` from this repo, paste its full contents in, and click **Run**. This creates every table, the row-level security policies, and two helper functions (`award_xp`, `seed_default_tasks`).
4. Go to **Project Settings → API**. You'll need two values from this page in the next step: the **Project URL** and the **anon public** key.

## 2. Configure environment variables

```bash
cp .env.example .env
```

Open `.env` and paste in your Project URL and anon key from step 1.4. Never commit `.env` — it's already in `.gitignore`.

## 3. Run it locally

```bash
npm install
npm run dev
```

Open the printed `localhost` URL. Sign up with any email/password — Supabase will send a confirmation email (check your project's Auth settings if you want to disable that requirement for testing).

The first time a user logs in, `seed_default_tasks()` automatically populates their checklist, including the 5 daily prayers.

## 4. Push to GitHub

This folder is already a git repository with an initial commit. Create an empty repository on GitHub (do **not** initialize it with a README), then:

```bash
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git branch -M main
git push -u origin main
```

## 5. Deploy (optional)

Any static host that supports Vite works. The easiest path:

- **Vercel**: import the GitHub repo, it auto-detects Vite. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` as Environment Variables in the project settings.
- **Netlify**: same idea — build command `npm run build`, publish directory `dist`, same two environment variables.

## How the data model works

- `task_templates` — a user's recurring checklist (the prayers + default tasks are seeded once per new user).
- `task_completions` — one row per template marked done on a given date; this is what "resets" each day without losing history.
- `profiles` — holds `xp` and `current_streak` / `longest_streak`, updated atomically by the `award_xp()` Postgres function so the streak can't be double-counted or raced.
- `brain_dumps` — free-form captured thoughts from the Dump tab.

Every table has row-level security enabled, scoped to `auth.uid()`, so each user can only ever read or write their own rows.

One intentional design choice: unchecking a completed task removes it from today's list but does **not** subtract the XP already earned. Clawing back rewards is demotivating and works against the positive-reinforcement design this app is built around.

## Project structure

```
src/
  components/   shared UI pieces (TaskCard, AddSheet, AuthScreen, regulation tools...)
  tabs/         the 4 main screens (Today, Focus, Dump, Wins)
  hooks/        Supabase-backed data hooks (useAuth, useTasks, useProfile, useBrainDumps)
  data/         static clinical content (CBT tips, achievements, suggestions...)
  lib/          Supabase client
supabase/
  schema.sql    full database schema — run this in the Supabase SQL Editor
```
