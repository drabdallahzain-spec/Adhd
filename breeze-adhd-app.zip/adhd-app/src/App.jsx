import { useState } from "react";
import { Flame, Star, Sparkles, Home, Target, Brain, Award, LogOut } from "lucide-react";

import { useAuth } from "./hooks/useAuth";
import { useProfile } from "./hooks/useProfile";
import { useTasks } from "./hooks/useTasks";
import { useBrainDumps } from "./hooks/useBrainDumps";

import AuthScreen from "./components/AuthScreen";
import AddSheet from "./components/AddSheet";

import TodayTab from "./tabs/TodayTab";
import FocusTab from "./tabs/FocusTab";
import DumpTab from "./tabs/DumpTab";
import WinsTab from "./tabs/WinsTab";

import { todayStr } from "./data/constants";

function LoadingScreen() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-100 to-indigo-50 flex flex-col items-center justify-center gap-3">
      <span className="text-6xl animate-pulse">☁️</span>
      <p className="text-gray-500 font-bold text-sm">Loading Breeze...</p>
    </div>
  );
}

function AppShell({ userId, signOut }) {
  const [energy, setEnergy] = useState("medium");
  const [tab, setTab] = useState("today");
  const [showAdd, setShowAdd] = useState(false);
  const [toast, setToast] = useState(null);

  const { profile, awardXp } = useProfile(userId);
  const { tasks, toggleTask, addTask } = useTasks(userId, (earned) => {
    awardXp(earned);
    toast2(`+${earned} XP! 🎉`);
  });
  const { dumps, addDump, markConverted } = useBrainDumps(userId);

  const xp = profile?.xp ?? 0;
  const streak = profile?.current_streak ?? 0;

  const done = tasks.filter((t) => t.done).length;
  const total = tasks.length;
  const pct = total > 0 ? Math.round((done / total) * 100) : 0;

  const cloudFace = pct === 100 ? "🥳" : pct >= 50 ? "😊" : pct > 0 ? "🙂" : "😴";
  const cloudGlow = pct === 100 ? "from-violet-100 to-fuchsia-50"
    : energy === "crisis" ? "from-red-50 to-orange-50"
    : pct >= 50 ? "from-cyan-100 to-sky-50" : "from-blue-100 to-indigo-50";

  function toast2(msg) { setToast(msg); setTimeout(() => setToast(null), 2000); }

  const handleAddTask = async (item) => {
    if (tasks.some((t) => t.text === item.text)) return;
    await addTask(item);
    setShowAdd(false);
    toast2("Task added ✓");
  };

  const addedSet = new Set(tasks.map((t) => t.text));

  const TABS = [
    { id: "today", icon: <Home size={18} />, label: "Today" },
    { id: "focus", icon: <Target size={18} />, label: "Focus" },
    { id: "dump", icon: <Brain size={18} />, label: "Dump" },
    { id: "wins", icon: <Award size={18} />, label: "Wins" },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex justify-center">
      <div className="w-full max-w-sm min-h-screen flex flex-col relative">

        {toast && (
          <div className="fixed top-5 left-1/2 -translate-x-1/2 z-[70] bg-blue-500 text-white text-sm font-black px-4 py-2.5 rounded-full shadow-xl flex items-center gap-2 whitespace-nowrap">
            <Sparkles size={13} /> {toast}
          </div>
        )}

        <div className={`bg-gradient-to-b ${cloudGlow} pt-10 pb-4 px-4 transition-all duration-700`}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-1.5 bg-white/70 rounded-full px-2.5 py-1 shadow-sm">
              <Flame size={13} className="text-orange-400" />
              <span className="text-sm font-black text-gray-700">{streak} day streak</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 bg-white/70 rounded-full px-2.5 py-1 shadow-sm">
                <Star size={13} className="text-amber-400" />
                <span className="text-sm font-black text-amber-600">{xp} XP</span>
              </div>
              <button onClick={signOut} className="w-7 h-7 bg-white/70 rounded-full flex items-center justify-center shadow-sm" title="Sign out">
                <LogOut size={13} className="text-gray-500" />
              </button>
            </div>
          </div>
          <div className="flex items-center gap-3.5">
            <div className="relative flex-shrink-0">
              <span className="text-6xl select-none" style={{ filter: "drop-shadow(0 4px 12px rgba(147,197,253,0.5))" }}>☁️</span>
              <span className="absolute inset-0 flex items-center justify-center text-2xl pb-1.5 pointer-events-none">{cloudFace}</span>
            </div>
            <div>
              <p className="font-black text-gray-800 text-sm">{todayStr()}</p>
              <p className="text-[11px] text-gray-500 font-semibold">{done}/{total} done · {pct}% complete</p>
              {pct === 100 && total > 0 && (
                <p className="text-[11px] text-violet-600 font-black mt-0.5 flex items-center gap-1"><Sparkles size={11} /> All done — incredible!</p>
              )}
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto pb-20">
          {tab === "today" && (
            <TodayTab
              tasks={tasks} energy={energy} onEnergyChange={setEnergy}
              onToggle={toggleTask} onFocusTask={() => setTab("focus")}
              onAddTask={handleAddTask} onOpenAdd={() => setShowAdd(true)}
              onBonusXP={(earned) => { awardXp(earned); toast2(`+${earned} XP Bonus! 🕌`); }}
            />
          )}
          {tab === "focus" && <FocusTab tasks={tasks} onToggle={toggleTask} />}
          {tab === "dump" && (
            <DumpTab dumps={dumps} addDump={addDump} markConverted={markConverted} onAddTask={handleAddTask} />
          )}
          {tab === "wins" && <WinsTab tasks={tasks} xp={xp} streak={streak} dumps={dumps} />}
        </div>

        <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-sm bg-white border-t border-gray-100 flex px-2 py-2 z-40 shadow-xl">
          {TABS.map((t) => (
            <button
              key={t.id} onClick={() => setTab(t.id)}
              className={`flex-1 flex flex-col items-center gap-0.5 py-1 rounded-xl transition-all ${tab === t.id ? "text-blue-500 bg-blue-50" : "text-gray-400"}`}
            >
              {t.icon}
              <span className="text-[10px] font-black">{t.label}</span>
            </button>
          ))}
        </div>

        {showAdd && <AddSheet addedSet={addedSet} onAdd={handleAddTask} onClose={() => setShowAdd(false)} />}
      </div>
    </div>
  );
}

export default function App() {
  const { user, loading, signUp, signIn, signOut } = useAuth();

  if (loading) return <LoadingScreen />;
  if (!user) return <AuthScreen onSignIn={signIn} onSignUp={signUp} />;

  // key={user.id} forces a clean remount of all data hooks on account switch
  return <AppShell key={user.id} userId={user.id} signOut={signOut} />;
}
