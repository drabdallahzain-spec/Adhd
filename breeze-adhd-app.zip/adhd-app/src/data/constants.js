// ══════════════════════════════════════════════════════════════════
//  CLINICAL DATABASE  (Psychiatry + Behavioral Modification)
// ══════════════════════════════════════════════════════════════════

export const ENERGY_LEVELS = [
  { id: "crisis", emoji: "🆘", label: "Crisis",  desc: "Just exist. That's enough today.",     border: "border-red-300",    bg: "bg-red-50",    text: "text-red-600"    },
  { id: "low",    emoji: "🪫", label: "Drained", desc: "Basics only. Be gentle with yourself.", border: "border-orange-300", bg: "bg-orange-50", text: "text-orange-600" },
  { id: "medium", emoji: "⚡", label: "Okay",    desc: "You can manage a few things.",          border: "border-blue-300",   bg: "bg-blue-50",   text: "text-blue-600"   },
  { id: "high",   emoji: "🔋", label: "Charged", desc: "Let's make this count!",                border: "border-green-300",  bg: "bg-green-50",  text: "text-green-600"  },
];

// HALT = core ADHD needs check (Hungry / Anxious / Lonely / Tired)
export const HALT = [
  { id: "hungry",  emoji: "🍽️", label: "Hungry?", fix: "Have something to eat first", task: { emoji: "🍽️", text: "Eat something nourishing",       category: "Self-care", timeMin: 10, difficulty: "easy", energyNeeded: "low" } },
  { id: "anxious", emoji: "😰", label: "Anxious?", fix: "3 slow breaths → then start", task: { emoji: "💨", text: "Take 5 deep breaths",             category: "Calm",      timeMin: 2,  difficulty: "easy", energyNeeded: "low" } },
  { id: "lonely",  emoji: "💙", label: "Lonely?", fix: "Send one quick text to someone", task: { emoji: "💙", text: "Text someone you care about",      category: "Self-care", timeMin: 2,  difficulty: "easy", energyNeeded: "low" } },
  { id: "tired",   emoji: "😴", label: "Tired?", fix: "Water + 5-min rest first",       task: { emoji: "💧", text: "Drink water & rest for 5 minutes", category: "Self-care", timeMin: 5,  difficulty: "easy", energyNeeded: "low" } },
];

// CBT-based "stuck" reframes (evidence-based for ADHD)
export const STUCK_TIPS = [
  { title: "2-Minute Rule",    body: "Commit to just 2 minutes. Tell yourself you can stop after that. Starting is the hardest part — your brain will usually keep going." },
  { title: "Shrink the Step",  body: "Break it down to the absolute smallest first action. Not 'clean room' — just 'pick up ONE item.' Lower the bar until it feels ridiculous." },
  { title: "Move Your Body",   body: "Stand up, shake your hands, walk 5 steps. Physical movement boosts dopamine and activates the prefrontal cortex within seconds." },
  { title: "Anchor It",        body: "Pair this task with something you already do: 'After I make my coffee, I'll do this.' Habit stacking bypasses initiation difficulty." },
  { title: "Change Location",  body: "Move somewhere else — even one chair over. New environments reduce the activation energy needed to start a task." },
  { title: "Name the Block",   body: "Say out loud: 'I notice I'm avoiding this.' Naming your avoidance activates your prefrontal cortex and weakens the freeze response." },
  { title: "Imperfect Action", body: "Give yourself permission to do it badly. A messy attempt is neurologically superior to a perfect plan never started." },
  { title: "3-2-1 Launch",     body: "Count down from 3 out loud. At 1, your body moves before your brain can object. Used by astronauts and athletes to override hesitation." },
];

// ADHD psychoeducation (evidence-based neuroscience)
export const ADHD_SCIENCE = [
  "ADHD brains need 3× more external rewards than neurotypical brains. Celebrating small wins is literally medicine — it triggers real dopamine release.",
  "Time blindness is neurological, not laziness. ADHD brains have impaired prospective memory. Using timers re-trains your brain's time-keeping circuits.",
  "Decision fatigue hits ADHD brains twice as fast. Pre-planning choices the night before (clothes, meals, tasks) saves critical executive function for what matters.",
  "Body doubling works because social presence activates the prefrontal cortex. Working with someone nearby — even virtually — is a legitimate ADHD accommodation.",
  "The 'just start' technique works: 85% of people who begin a task continue once started. Your brain only needs to overcome initiation — momentum does the rest.",
  "ADHD brains run on interest, novelty, challenge, or urgency — not importance. Building these elements into tasks isn't cheating; it's working with your neurology.",
  "5 minutes of movement increases dopamine, norepinephrine, and serotonin by up to 20%. Move before you need to focus — it's the most underused ADHD tool.",
  "Sleep deprivation mimics and amplifies ADHD symptoms. Consistent sleep timing — even on weekends — can reduce ADHD severity significantly.",
];

// Shame-reducing affirmations (ADHD-aware)
export const AFFIRMATIONS = [
  "Your brain is wired for creativity and hyperfocus. That's a genuine superpower.",
  "You don't have a willpower problem. You have a dopamine regulation difference.",
  "Done imperfectly today is better than perfect in your head forever.",
  "You are not broken. You are differently wired — and that difference has value.",
  "Every small win produces real dopamine. Celebrate every single one.",
  "Rest is not laziness. Rest is neurological maintenance.",
  "Showing up today, even a little, is a genuine victory for your brain.",
];

// 5-4-3-2-1 Grounding (sensory grounding for anxiety/overwhelm)
export const GROUNDING = [
  { n: 5, emoji: "👁️", sense: "see",   prompt: "Name 5 things you can SEE right now"               },
  { n: 4, emoji: "✋", sense: "touch", prompt: "Name 4 things you can TOUCH or feel right now"      },
  { n: 3, emoji: "👂", sense: "hear",  prompt: "Name 3 sounds you can HEAR right now"               },
  { n: 2, emoji: "👃", sense: "smell", prompt: "Name 2 things you can SMELL (or love to smell)"     },
  { n: 1, emoji: "👅", sense: "taste", prompt: "Name 1 thing you can TASTE or notice in your mouth" },
];

// Prayer metadata (shown in PrayerTracker card)
export const PRAYERS_META = [
  { id: "fajr",    ar: "الفجر",  en: "Fajr",    emoji: "🌅", time: "Dawn"      },
  { id: "dhuhr",   ar: "الظهر",  en: "Dhuhr",   emoji: "☀️", time: "Midday"    },
  { id: "asr",     ar: "العصر",  en: "Asr",     emoji: "🌤️", time: "Afternoon" },
  { id: "maghrib", ar: "المغرب", en: "Maghrib", emoji: "🌆", time: "Sunset"    },
  { id: "isha",    ar: "العشاء", en: "Isha",    emoji: "🌙", time: "Night"     },
];

// Achievements (token economy — behavioral modification).
// `check` receives { tasks, xp, streak, dumps }.
export const ACHIEVEMENTS = [
  { id: "first",    emoji: "🌱", label: "First Step",  desc: "Complete your first task",        check: ({ tasks })          => tasks.filter((t) => t.done).length >= 1 },
  { id: "quick",    emoji: "⚡", label: "Quick Winner", desc: "Complete a task under 3 min",     check: ({ tasks })          => tasks.some((t) => t.done && t.timeMin <= 3) },
  { id: "hard",     emoji: "💪", label: "Hard Mode",    desc: "Complete a hard-difficulty task", check: ({ tasks })          => tasks.some((t) => t.done && t.difficulty === "hard") },
  { id: "streak",   emoji: "🔥", label: "3-Day Streak", desc: "Maintain a 3-day streak",         check: ({ streak })         => streak >= 3 },
  { id: "xp100",    emoji: "⭐", label: "XP Collector", desc: "Earn 100 XP",                     check: ({ xp })             => xp >= 100 },
  { id: "allday",   emoji: "🏆", label: "Full Day",     desc: "Complete every task today",       check: ({ tasks })          => tasks.length > 0 && tasks.every((t) => t.done) },
  { id: "dump",     emoji: "🧠", label: "Mind Clear",   desc: "Use the Brain Dump feature",      check: ({ dumps })          => dumps.length > 0 },
  { id: "focus",    emoji: "🎯", label: "Deep Focus",   desc: "Earn 45+ XP in a day",            check: ({ xp })             => xp >= 45 },
  { id: "prayers5", emoji: "🕌", label: "5 Pillars",    desc: "Complete all 5 daily prayers",    check: ({ tasks })          => tasks.filter((t) => t.category === "Prayer" && t.done).length >= 5 },
];

export const SUGGESTIONS = {
  "Self-care": [
    { emoji: "💧", text: "Drink a full glass of water",  timeMin: 1,  difficulty: "easy",   energyNeeded: "low",    category: "Self-care" },
    { emoji: "🥣", text: "Have breakfast",                timeMin: 10, difficulty: "medium", energyNeeded: "medium", category: "Self-care" },
    { emoji: "💊", text: "Take your medication",          timeMin: 1,  difficulty: "easy",   energyNeeded: "low",    category: "Self-care" },
    { emoji: "📵", text: "Screens off 30 min before bed", timeMin: 2,  difficulty: "easy",   energyNeeded: "low",    category: "Self-care" },
    { emoji: "🚿", text: "Take a warm shower",             timeMin: 10, difficulty: "medium", energyNeeded: "medium", category: "Self-care" },
    { emoji: "🪥", text: "Brush and floss your teeth",     timeMin: 3,  difficulty: "easy",   energyNeeded: "low",    category: "Self-care" },
    { emoji: "🧴", text: "Moisturize your skin",           timeMin: 2,  difficulty: "easy",   energyNeeded: "low",    category: "Self-care" },
    { emoji: "🥑", text: "Prepare a healthy snack",        timeMin: 5,  difficulty: "easy",   energyNeeded: "low",    category: "Self-care" },
  ],
  "Calm": [
    { emoji: "🌬️", text: "Get some fresh air",            timeMin: 5,  difficulty: "easy", energyNeeded: "low", category: "Calm" },
    { emoji: "🎵", text: "Listen to calming music",        timeMin: 10, difficulty: "easy", energyNeeded: "low", category: "Calm" },
    { emoji: "💨", text: "Box breathing (4-4-4-4)",        timeMin: 5,  difficulty: "easy", energyNeeded: "low", category: "Calm" },
    { emoji: "🍵", text: "Make a warm drink and savor it", timeMin: 10, difficulty: "easy", energyNeeded: "low", category: "Calm" },
    { emoji: "⏱️", text: "15-minute screen break",         timeMin: 15, difficulty: "easy", energyNeeded: "low", category: "Calm" },
  ],
  "Mindfulness": [
    { emoji: "🕯️", text: "Practice mindful breathing",        timeMin: 3, difficulty: "easy", energyNeeded: "low", category: "Mindfulness" },
    { emoji: "🌤️", text: "5-4-3-2-1 grounding exercise",      timeMin: 5, difficulty: "easy", energyNeeded: "low", category: "Mindfulness" },
    { emoji: "💗", text: "Write one thing that went well",     timeMin: 3, difficulty: "easy", energyNeeded: "low", category: "Mindfulness" },
    { emoji: "💝", text: "Name one thing you're grateful for", timeMin: 2, difficulty: "easy", energyNeeded: "low", category: "Mindfulness" },
    { emoji: "🪨", text: "5-minute body scan",                 timeMin: 5, difficulty: "easy", energyNeeded: "low", category: "Mindfulness" },
  ],
  "Move": [
    { emoji: "🏃", text: "Walk for 10 minutes",          timeMin: 10, difficulty: "medium", energyNeeded: "medium", category: "Move" },
    { emoji: "🧘", text: "5 minutes of gentle stretching", timeMin: 5, difficulty: "easy",   energyNeeded: "low",    category: "Move" },
    { emoji: "💪", text: "10 jumping jacks",              timeMin: 2,  difficulty: "medium", energyNeeded: "medium", category: "Move" },
    { emoji: "🚶", text: "Stand up and walk around",      timeMin: 3,  difficulty: "easy",   energyNeeded: "low",    category: "Move" },
  ],
};

export const CAT = {
  "Productivity": { color: "text-amber-500",   bg: "bg-amber-50"   },
  "Self-care":    { color: "text-rose-400",    bg: "bg-rose-50"    },
  "Move":         { color: "text-emerald-500", bg: "bg-emerald-50" },
  "Mindfulness":  { color: "text-violet-500",  bg: "bg-violet-50"  },
  "Calm":         { color: "text-sky-500",     bg: "bg-sky-50"     },
  "Prayer":       { color: "text-teal-600",    bg: "bg-teal-50"    },
};

export const DIFF = {
  easy:   { label: "Easy",   color: "text-emerald-600", bg: "bg-emerald-50" },
  medium: { label: "Medium", color: "text-amber-600",   bg: "bg-amber-50"   },
  hard:   { label: "Hard",   color: "text-rose-600",    bg: "bg-rose-50"    },
};

export const ENERGY_RANK = { low: 1, medium: 2, high: 3 };
export const ENERGY_CAP  = { crisis: 0, low: 1, medium: 2, high: 3 };

export const pad = (n) => String(n).padStart(2, "0");
export const fmt = (s) => `${pad(Math.floor(s / 60))}:${pad(s % 60)}`;
export const todayStr = () =>
  new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" });
