import { useRef, useState } from "react";
import { Check } from "lucide-react";

const MOODS = [
  { id: "great", emoji: "😄", label: "Great" },
  { id: "okay", emoji: "😐", label: "Okay" },
  { id: "anxious", emoji: "😰", label: "Anxious" },
  { id: "sad", emoji: "😔", label: "Sad" },
  { id: "angry", emoji: "😠", label: "Angry" },
  { id: "overwhelmed", emoji: "🤯", label: "Overwhelmed" },
];

export default function DumpTab({ dumps, addDump, markConverted, onAddTask }) {
  const [mood, setMood] = useState(null);
  const [text, setText] = useState("");
  const ref = useRef(null);

  const dump = async () => {
    const lines = text.split("\n").map((l) => l.trim()).filter(Boolean);
    if (!lines.length) return;
    for (const line of lines) await addDump(line, mood);
    setText("");
    ref.current?.focus();
  };

  const convert = async (item) => {
    await onAddTask({ emoji: "📝", text: item.content, category: "Productivity", timeMin: 5, difficulty: "medium", energyNeeded: "medium", habitStack: "" });
    await markConverted(item.id);
  };

  return (
    <div className="flex flex-col gap-3 px-4 py-4">
      <div className="bg-white rounded-2xl p-3.5 shadow-sm">
        <p className="text-[11px] font-black text-gray-400 uppercase tracking-widest mb-2.5">💭 How are you feeling?</p>
        <div className="flex gap-1.5 flex-wrap">
          {MOODS.map((m) => (
            <button
              key={m.id} onClick={() => setMood(m.id)}
              className={`flex items-center gap-1 rounded-full px-2.5 py-1.5 border transition-all text-xs font-black ${
                mood === m.id ? "border-blue-300 bg-blue-50 text-blue-600" : "border-gray-100 text-gray-500"
              }`}
            >
              {m.emoji} {m.label}
            </button>
          ))}
        </div>
        {mood === "overwhelmed" && (
          <div className="mt-2.5 bg-violet-50 rounded-xl p-2.5">
            <p className="text-violet-700 font-bold text-xs leading-relaxed">
              🌿 That's okay. Overwhelm is your brain's signal that it's carrying too much. Dump everything below — getting it out of your head is the first step.
            </p>
          </div>
        )}
        {mood === "anxious" && (
          <div className="mt-2.5 bg-blue-50 rounded-xl p-2.5">
            <p className="text-blue-700 font-bold text-xs leading-relaxed">
              💨 Try 3 slow breaths before you start. Anxiety narrows focus — dumping your thoughts will help widen it again.
            </p>
          </div>
        )}
      </div>

      <div className="bg-white rounded-2xl p-4 shadow-sm">
        <p className="text-[11px] font-black text-gray-400 uppercase tracking-widest mb-1">🧠 Brain Dump</p>
        <p className="text-gray-400 text-[11px] font-semibold mb-3">No filter. No judgment. One thought per line. Just get it out of your head.</p>
        <textarea
          ref={ref} value={text} onChange={(e) => setText(e.target.value)}
          placeholder={"Anything on your mind...\nWorries, ideas, to-dos, anything.\nOne thought per line."}
          rows={5}
          className="w-full text-sm text-gray-800 font-semibold resize-none outline-none placeholder-gray-300 leading-relaxed"
        />
        <button
          onClick={dump} disabled={!text.trim()}
          className="mt-3 w-full bg-blue-500 text-white font-black text-sm py-2.5 rounded-xl disabled:opacity-30 hover:bg-blue-600 transition-colors shadow-md shadow-blue-100"
        >
          Dump It 🧠
        </button>
        <p className="text-center text-[10px] text-gray-300 mt-2 font-semibold">Clearing working memory reduces cognitive load</p>
      </div>

      {dumps.length > 0 && (
        <div className="space-y-2">
          <p className="text-[11px] font-black text-gray-400 uppercase tracking-widest">
            Captured ({dumps.filter((d) => !d.converted).length} to process)
          </p>
          {dumps.map((d) => (
            <div key={d.id} className={`bg-white rounded-xl px-4 py-3 shadow-sm flex items-start gap-3 transition-all ${d.converted ? "opacity-30" : ""}`}>
              <span className="text-gray-700 font-semibold text-sm flex-1 leading-snug">{d.content}</span>
              {d.converted
                ? <Check size={14} className="text-emerald-400 flex-shrink-0 mt-0.5" />
                : <button onClick={() => convert(d)} className="text-[11px] font-black text-blue-500 bg-blue-50 px-2.5 py-1 rounded-full flex-shrink-0 mt-0.5">→ Task</button>}
            </div>
          ))}
          {dumps.some((d) => !d.converted) && (
            <p className="text-[10px] text-gray-400 text-center font-semibold">Tap "→ Task" to add anything to your task list</p>
          )}
        </div>
      )}

      {dumps.length === 0 && (
        <div className="text-center py-8 text-gray-300">
          <span className="text-4xl block mb-2">🧠</span>
          <p className="text-sm font-semibold">Your captured thoughts will appear here</p>
          <p className="text-[11px] mt-1">Externalizing thoughts frees up ADHD working memory</p>
        </div>
      )}
    </div>
  );
}
