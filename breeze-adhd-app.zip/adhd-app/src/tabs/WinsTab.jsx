import { Flame, Trophy, Zap, Award, Star } from "lucide-react";
import { ACHIEVEMENTS, AFFIRMATIONS, ADHD_SCIENCE } from "../data/constants";

export default function WinsTab({ tasks, xp, streak, dumps }) {
  const done = tasks.filter((t) => t.done).length;
  const total = tasks.length;
  const pct = total > 0 ? Math.round((done / total) * 100) : 0;
  const level = Math.floor(xp / 100) + 1;
  const lvlXP = xp % 100;
  const dayIdx = new Date().getDay();
  const hardDone = tasks.filter((t) => t.done && t.difficulty === "hard").length;

  const ctx = { tasks, xp, streak, dumps };
  const unlocked = ACHIEVEMENTS.filter((a) => a.check(ctx));

  return (
    <div className="flex flex-col gap-3 px-4 py-4">
      <div className="bg-gradient-to-br from-violet-50 via-blue-50 to-fuchsia-50 rounded-2xl p-4 border border-violet-100">
        <p className="text-violet-600 font-black text-[11px] uppercase tracking-widest mb-2">✨ Today's Affirmation</p>
        <p className="text-gray-800 font-black text-base leading-snug">"{AFFIRMATIONS[dayIdx % AFFIRMATIONS.length]}"</p>
      </div>

      <div className="bg-white rounded-2xl p-4 shadow-sm">
        <div className="flex items-center justify-between mb-2">
          <div>
            <p className="font-black text-gray-800 text-base">Level {level}</p>
            <p className="text-gray-400 text-xs font-semibold">{100 - lvlXP} XP until next level</p>
          </div>
          <div className="flex items-center gap-1.5 bg-amber-50 rounded-full px-3 py-1.5">
            <Star size={13} className="text-amber-400" />
            <span className="font-black text-amber-600 text-sm">{xp} XP</span>
          </div>
        </div>
        <div className="w-full bg-gray-100 rounded-full h-3 overflow-hidden">
          <div className="h-full rounded-full transition-all duration-700" style={{ width: `${lvlXP}%`, background: "linear-gradient(90deg,#f59e0b,#fbbf24)" }} />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        {[
          { icon: <Flame size={22} className="mx-auto text-orange-400 mb-1" />, val: streak, label: "Day Streak" },
          { icon: <Trophy size={22} className="mx-auto text-amber-400 mb-1" />, val: `${done}/${total}`, label: "Done Today" },
          { icon: <Zap size={22} className="mx-auto text-blue-400 mb-1" />, val: `${pct}%`, label: "Completed" },
          { icon: <Award size={22} className="mx-auto text-violet-400 mb-1" />, val: hardDone, label: "Hard Wins" },
        ].map((s, i) => (
          <div key={i} className="bg-white rounded-2xl p-4 shadow-sm text-center">
            {s.icon}
            <p className="text-2xl font-black text-gray-800">{s.val}</p>
            <p className="text-[11px] text-gray-400 font-bold">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-2xl p-4 shadow-sm">
        <p className="text-[11px] font-black text-gray-400 uppercase tracking-widest mb-3">
          🏆 Achievements — {unlocked.length}/{ACHIEVEMENTS.length} unlocked
        </p>
        <div className="grid grid-cols-4 gap-2">
          {ACHIEVEMENTS.map((a) => {
            const got = unlocked.some((u) => u.id === a.id);
            return (
              <div key={a.id} title={a.desc} className={`rounded-xl p-2 text-center border transition-all ${got ? "bg-amber-50 border-amber-100" : "bg-gray-50 border-gray-100 opacity-35"}`}>
                <span className="text-2xl block">{a.emoji}</span>
                <p className="text-[9px] font-black text-gray-700 mt-1 leading-tight">{a.label}</p>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-blue-50 rounded-2xl p-4 border border-blue-100">
        <p className="text-blue-600 font-black text-[11px] uppercase tracking-widest mb-2">🔬 ADHD Science</p>
        <p className="text-gray-700 font-semibold text-sm leading-relaxed">{ADHD_SCIENCE[dayIdx % ADHD_SCIENCE.length]}</p>
      </div>
    </div>
  );
}
