import { Plus } from "lucide-react";
import { EnergySelector, HALTBanner } from "../components/DailyCheckIn";
import PrayerTracker from "../components/PrayerTracker";
import TaskCard from "../components/TaskCard";
import { ENERGY_RANK, ENERGY_CAP } from "../data/constants";

export default function TodayTab({ tasks, energy, onEnergyChange, onToggle, onFocusTask, onAddTask, onOpenAdd, onBonusXP }) {
  const cap = ENERGY_CAP[energy];
  const visible = (energy === "crisis"
    ? tasks.filter((t) => t.difficulty === "easy" && t.timeMin <= 3)
    : tasks.filter((t) => ENERGY_RANK[t.energyNeeded] <= cap + 1)
  ).filter((t) => t.category !== "Prayer");
  const quickWins = visible.filter((t) => !t.done && t.timeMin <= 3);
  const done = tasks.filter((t) => t.done).length;
  const total = tasks.length;
  const pct = total > 0 ? Math.round((done / total) * 100) : 0;

  return (
    <div className="flex flex-col gap-3 px-4 py-4">
      <EnergySelector energy={energy} onChange={onEnergyChange} />

      <PrayerTracker tasks={tasks} onToggle={onToggle} onBonusXP={onBonusXP} />

      {energy === "crisis" && (
        <div className="bg-red-50 border border-red-100 rounded-2xl p-4">
          <p className="text-red-700 font-black text-[11px] uppercase tracking-widest mb-1">🆘 Crisis Mode Active</p>
          <p className="text-gray-700 font-semibold text-sm leading-relaxed">
            Showing only the easiest tasks (under 3 min). Your only job right now is to exist. That is genuinely enough.
          </p>
        </div>
      )}

      <HALTBanner onAddTask={onAddTask} />

      <div className="bg-white rounded-2xl px-4 py-3 shadow-sm">
        <div className="flex justify-between items-center mb-2">
          <p className="font-black text-gray-800 text-sm">{visible.length} tasks for your energy level</p>
          <button onClick={() => onFocusTask(null)} className="text-[11px] font-black text-blue-500 bg-blue-50 rounded-full px-2.5 py-1">
            Focus Mode →
          </button>
        </div>
        <div className="w-full bg-gray-100 rounded-full h-2.5 overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-700"
            style={{ width: `${pct}%`, background: pct === 100 ? "linear-gradient(90deg,#a78bfa,#f472b6)" : "linear-gradient(90deg,#60a5fa,#93c5fd)" }}
          />
        </div>
        <p className="text-right text-[10px] text-gray-400 mt-1 font-semibold">{done}/{total} complete · {pct}%</p>
      </div>

      {quickWins.length > 0 && (
        <div>
          <p className="text-[11px] font-black text-emerald-600 uppercase tracking-widest mb-2">⚡ Quick Wins — Under 3 Min</p>
          <div className="space-y-2">
            {quickWins.slice(0, 3).map((t) => (
              <TaskCard key={t.id} task={t} onToggle={onToggle} onFocus={onFocusTask} highlight />
            ))}
          </div>
        </div>
      )}

      <div>
        <div className="flex items-center justify-between mb-2">
          <p className="text-[11px] font-black text-gray-400 uppercase tracking-widest">All Tasks</p>
          <button onClick={onOpenAdd} className="flex items-center gap-1 text-[11px] font-black text-blue-500">
            <Plus size={11} /> Add task
          </button>
        </div>
        <div className="space-y-2">
          {visible.map((t) => <TaskCard key={t.id} task={t} onToggle={onToggle} onFocus={onFocusTask} />)}
        </div>
        {visible.length === 0 && (
          <div className="text-center py-8">
            <p className="text-sm font-bold text-gray-300">No tasks match your current energy.</p>
            <p className="text-xs text-gray-300 mt-1">Raise your energy level above, or add simple tasks.</p>
          </div>
        )}
      </div>

      <button
        onClick={onOpenAdd}
        className="w-full flex items-center gap-2.5 bg-white rounded-2xl px-4 py-3 shadow-sm text-blue-500 font-black text-sm hover:shadow-md transition-shadow"
      >
        <div className="w-7 h-7 bg-blue-50 rounded-full flex items-center justify-center">
          <Plus size={14} className="text-blue-500" />
        </div>
        Add a task
      </button>
    </div>
  );
}
