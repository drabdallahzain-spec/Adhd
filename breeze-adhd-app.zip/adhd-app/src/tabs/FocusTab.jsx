import { useState } from "react";
import { Check, Shuffle } from "lucide-react";
import { PomodoroTimer, BoxBreathing, Grounding } from "../components/RegulationTools";
import { CAT, DIFF, STUCK_TIPS } from "../data/constants";

export default function FocusTab({ tasks, onToggle }) {
  const pending = tasks.filter((t) => !t.done);
  const [idx, setIdx] = useState(0);
  const [stuckIdx, setStuckIdx] = useState(0);
  const [showStuck, setShowStuck] = useState(false);
  const [showGround, setShowGround] = useState(false);
  const [showBreath, setShowBreath] = useState(false);

  if (pending.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 px-6 text-center gap-4">
        <span className="text-7xl">🥳</span>
        <h2 className="text-2xl font-black text-gray-800">Every task complete!</h2>
        <p className="text-gray-500 font-semibold leading-relaxed">Your brain worked genuinely hard today. You've earned rest without guilt.</p>
        <div className="bg-violet-50 rounded-2xl p-4 text-left w-full">
          <p className="text-violet-600 font-black text-[11px] uppercase tracking-widest mb-2">🧠 What just happened in your brain</p>
          <p className="text-gray-700 font-semibold text-sm leading-relaxed">
            Completing tasks triggered real dopamine releases all day. Your prefrontal cortex literally strengthened with each win. Rest now — it consolidates everything.
          </p>
        </div>
      </div>
    );
  }

  const safe = Math.min(idx, pending.length - 1);
  const task = pending[safe];
  const cat = CAT[task.category] || CAT["Mindfulness"];
  const diff = DIFF[task.difficulty] || DIFF.easy;

  const complete = () => { onToggle(task.id); setIdx((i) => Math.max(0, Math.min(i, pending.length - 2))); setShowStuck(false); };
  const shuffle = () => { setIdx(Math.floor(Math.random() * pending.length)); setShowStuck(false); };
  const skip = () => { setIdx((i) => (i + 1) % pending.length); setShowStuck(false); };
  const closeAll = () => { setShowStuck(false); setShowGround(false); setShowBreath(false); };

  return (
    <div className="flex flex-col gap-3 px-4 py-4">
      <div className="flex items-center justify-between">
        <p className="text-[11px] font-black text-gray-400 uppercase tracking-widest">
          {pending.length} task{pending.length !== 1 ? "s" : ""} remaining
        </p>
        <button onClick={shuffle} className="flex items-center gap-1.5 text-[11px] font-black text-blue-500 bg-blue-50 rounded-full px-3 py-1.5">
          <Shuffle size={11} /> Pick for me
        </button>
      </div>

      <div className="bg-white rounded-3xl p-5 shadow-md text-center">
        <span className="text-5xl block mb-3">{task.emoji}</span>
        <div className="flex items-center justify-center gap-2 mb-2">
          <span className={`text-[10px] font-black uppercase tracking-wider ${cat.color}`}>{task.category}</span>
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${diff.bg} ${diff.color}`}>{diff.label}</span>
        </div>
        <h2 className="text-xl font-black text-gray-800 leading-tight mb-1">{task.text}</h2>
        <p className="text-gray-400 font-semibold text-xs">~{task.timeMin} minute{task.timeMin !== 1 ? "s" : ""}</p>
        {task.habitStack && (
          <span className="inline-block mt-2 bg-gray-50 text-gray-400 text-[11px] font-semibold rounded-xl px-3 py-1.5">📌 Best: {task.habitStack}</span>
        )}
      </div>

      <PomodoroTimer taskName={task.text} />

      <div className="grid grid-cols-2 gap-2">
        <button onClick={() => { closeAll(); setShowStuck((s) => !s); }} className="py-3 rounded-xl bg-amber-50 text-amber-600 font-black text-sm flex items-center justify-center gap-1.5 hover:bg-amber-100 transition-colors">
          😵‍💫 I'm Stuck
        </button>
        <button onClick={complete} className="py-3 rounded-xl bg-blue-500 text-white font-black text-sm flex items-center justify-center gap-1.5 shadow-md shadow-blue-200 hover:bg-blue-600 transition-colors">
          <Check size={15} strokeWidth={3} /> Done!
        </button>
      </div>

      <div className="flex gap-2">
        <button onClick={() => { closeAll(); setShowGround((s) => !s); }} className={`flex-1 py-2 rounded-xl text-[11px] font-black flex items-center justify-center gap-1 transition-colors ${showGround ? "bg-violet-200 text-violet-700" : "bg-violet-50 text-violet-600"}`}>
          🌿 Ground Me
        </button>
        <button onClick={() => { closeAll(); setShowBreath((s) => !s); }} className={`flex-1 py-2 rounded-xl text-[11px] font-black flex items-center justify-center gap-1 transition-colors ${showBreath ? "bg-blue-200 text-blue-700" : "bg-blue-50 text-blue-500"}`}>
          💨 Breathe
        </button>
        {pending.length > 1 && (
          <button onClick={skip} className="flex-1 py-2 rounded-xl text-[11px] font-black text-gray-400 bg-gray-50 hover:bg-gray-100 transition-colors">Skip →</button>
        )}
      </div>

      {showStuck && (
        <div className="bg-amber-50 border border-amber-100 rounded-2xl p-4">
          <p className="text-amber-700 font-black text-[11px] uppercase tracking-widest mb-2">💡 {STUCK_TIPS[stuckIdx].title}</p>
          <p className="text-gray-700 font-semibold text-sm leading-relaxed">{STUCK_TIPS[stuckIdx].body}</p>
          <button onClick={() => setStuckIdx((i) => (i + 1) % STUCK_TIPS.length)} className="mt-2.5 text-[11px] font-black text-amber-600 underline underline-offset-2">
            Another strategy →
          </button>
        </div>
      )}

      {showGround && <Grounding onClose={() => setShowGround(false)} />}
      {showBreath && <BoxBreathing onClose={() => setShowBreath(false)} />}
    </div>
  );
}
