import { Check, Target } from "lucide-react";
import { CAT, DIFF } from "../data/constants";

export default function TaskCard({ task, onToggle, onFocus, highlight }) {
  const cat = CAT[task.category] || CAT["Mindfulness"];
  const diff = DIFF[task.difficulty] || DIFF.easy;

  return (
    <div className={`bg-white rounded-2xl px-4 py-3 shadow-sm flex items-center gap-3 transition-all duration-300
      ${task.done ? "opacity-40" : ""}
      ${highlight ? "border-l-4 border-emerald-300" : ""}`}>
      <span className="text-2xl leading-none flex-shrink-0">{task.emoji}</span>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 mb-0.5 flex-wrap">
          <span className={`text-[10px] font-black uppercase tracking-wider ${cat.color}`}>{task.category}</span>
          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${diff.bg} ${diff.color}`}>{diff.label}</span>
          <span className="text-[10px] text-gray-400 font-bold">~{task.timeMin}m</span>
        </div>
        <p className={`font-bold text-gray-800 text-sm leading-snug ${task.done ? "line-through text-gray-400" : ""}`}>
          {task.text}
        </p>
        {task.habitStack && !task.done && (
          <p className="text-[10px] text-gray-400 mt-0.5 truncate">📌 {task.habitStack}</p>
        )}
      </div>
      <div className="flex flex-col gap-1.5 items-center flex-shrink-0">
        {!task.done && onFocus && (
          <button onClick={() => onFocus(task)} className="w-7 h-7 bg-blue-50 rounded-lg flex items-center justify-center" title="Focus on this">
            <Target size={12} className="text-blue-500" />
          </button>
        )}
        <button
          onClick={() => onToggle(task.id)}
          className={`w-7 h-7 rounded-lg border-2 flex items-center justify-center transition-all duration-200 ${
            task.done ? "bg-blue-400 border-blue-400" : "border-gray-200 hover:border-blue-300"
          }`}
        >
          {task.done && <Check size={13} className="text-white" strokeWidth={3} />}
        </button>
      </div>
    </div>
  );
}
