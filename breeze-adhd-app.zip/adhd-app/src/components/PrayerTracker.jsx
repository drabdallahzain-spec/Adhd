import { useEffect, useRef } from "react";
import { Check } from "lucide-react";
import { PRAYERS_META } from "../data/constants";

export default function PrayerTracker({ tasks, onToggle, onBonusXP }) {
  const prayers = tasks.filter((t) => t.category === "Prayer");
  const doneCnt = prayers.filter((t) => t.done).length;
  const allDone = prayers.length > 0 && doneCnt === prayers.length;
  const prevDone = useRef(doneCnt);

  useEffect(() => {
    if (allDone && prevDone.current < prayers.length) onBonusXP(50);
    prevDone.current = doneCnt;
  }, [doneCnt, allDone, prayers.length, onBonusXP]);

  if (prayers.length === 0) return null;

  return (
    <div className={`rounded-2xl p-4 shadow-sm transition-all duration-500 ${
      allDone ? "bg-gradient-to-br from-teal-50 to-emerald-50 border border-teal-100" : "bg-white"
    }`}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2.5">
          <span className="text-2xl">🕌</span>
          <div>
            <p className="font-black text-gray-800 text-sm">الصلوات الخمس</p>
            <p className="text-[10px] text-gray-400 font-semibold tracking-wide">Daily Prayers</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className={`text-sm font-black ${allDone ? "text-teal-600" : "text-gray-500"}`}>{doneCnt}/{prayers.length}</span>
          {allDone && <span className="text-[10px] bg-teal-100 text-teal-700 font-black px-2 py-0.5 rounded-full">+50 XP 🎉</span>}
        </div>
      </div>

      <div className="w-full bg-gray-100 rounded-full h-1.5 mb-3 overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{ width: `${(doneCnt / prayers.length) * 100}%`, background: "linear-gradient(90deg,#2dd4bf,#10b981)" }}
        />
      </div>

      <div className="space-y-1.5">
        {PRAYERS_META.map((p) => {
          const task = prayers.find((t) => t.text.includes(p.en));
          if (!task) return null;
          return (
            <button
              key={p.id} onClick={() => onToggle(task.id)}
              className={`w-full flex items-center gap-3 rounded-xl px-3 py-2.5 transition-all text-left ${
                task.done ? "bg-teal-50" : "bg-gray-50 hover:bg-gray-100 active:scale-[0.98]"
              }`}
            >
              <span className="text-lg leading-none">{p.emoji}</span>
              <div className="flex-1 min-w-0">
                <p className={`font-black text-sm ${task.done ? "text-teal-700" : "text-gray-800"}`}>{p.ar}</p>
                <p className="text-[10px] text-gray-400 font-semibold">{p.en} · {p.time}</p>
              </div>
              <div className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center flex-shrink-0 transition-all duration-200 ${
                task.done ? "bg-teal-500 border-teal-500" : "border-gray-200"
              }`}>
                {task.done && <Check size={11} className="text-white" strokeWidth={3} />}
              </div>
            </button>
          );
        })}
      </div>

      {allDone && (
        <p className="text-center text-teal-600 font-black text-xs mt-3 py-1">
          🌟 الحمد لله — All prayers complete today!
        </p>
      )}
    </div>
  );
}
