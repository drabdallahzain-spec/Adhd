import { useState } from "react";

export default function AuthScreen({ onSignIn, onSignUp }) {
  const [mode, setMode] = useState("signin"); // "signin" | "signup"
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setNotice("");
    setBusy(true);

    const { error: err } =
      mode === "signin" ? await onSignIn(email, password) : await onSignUp(email, password);

    setBusy(false);

    if (err) {
      setError(err.message || "Something went wrong. Please try again.");
      return;
    }
    if (mode === "signup") {
      setNotice("Account created! Check your email to confirm, then sign in.");
      setMode("signin");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-100 to-indigo-50 flex justify-center items-center px-4">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-6">
          <span className="text-7xl mb-2 select-none" style={{ filter: "drop-shadow(0 4px 12px rgba(147,197,253,0.5))" }}>☁️</span>
          <h1 className="text-2xl font-black text-gray-800">Breeze</h1>
          <p className="text-gray-500 font-semibold text-sm mt-1 text-center">
            A gentle daily companion for ADHD brains
          </p>
        </div>

        <div className="bg-white rounded-3xl shadow-md p-5">
          <div className="flex bg-gray-50 rounded-xl p-1 mb-4">
            {["signin", "signup"].map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => { setMode(m); setError(""); setNotice(""); }}
                className={`flex-1 py-2 rounded-lg text-sm font-black transition-all ${
                  mode === m ? "bg-white text-blue-500 shadow-sm" : "text-gray-400"
                }`}
              >
                {m === "signin" ? "Sign In" : "Sign Up"}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="flex flex-col gap-3">
            <div>
              <label className="text-[11px] font-black text-gray-400 uppercase tracking-widest block mb-1">Email</label>
              <input
                type="email" required value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full bg-gray-50 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-gray-800 outline-none border-2 border-transparent focus:border-blue-300 transition-colors"
              />
            </div>
            <div>
              <label className="text-[11px] font-black text-gray-400 uppercase tracking-widest block mb-1">Password</label>
              <input
                type="password" required minLength={6} value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-gray-50 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-gray-800 outline-none border-2 border-transparent focus:border-blue-300 transition-colors"
              />
            </div>

            {error && (
              <p className="text-rose-600 bg-rose-50 rounded-xl px-3 py-2 text-xs font-bold leading-relaxed">{error}</p>
            )}
            {notice && (
              <p className="text-emerald-600 bg-emerald-50 rounded-xl px-3 py-2 text-xs font-bold leading-relaxed">{notice}</p>
            )}

            <button
              type="submit" disabled={busy}
              className="w-full bg-blue-500 text-white font-black text-sm py-3 rounded-xl shadow-md shadow-blue-200 hover:bg-blue-600 transition-colors disabled:opacity-50 mt-1"
            >
              {busy ? "One moment..." : mode === "signin" ? "Sign In" : "Create Account"}
            </button>
          </form>
        </div>

        <p className="text-center text-gray-400 text-[11px] font-semibold mt-4">
          Your data is private and only visible to you.
        </p>
      </div>
    </div>
  );
}
