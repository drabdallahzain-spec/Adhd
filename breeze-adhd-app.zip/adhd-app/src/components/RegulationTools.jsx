import { useEffect, useRef, useState } from "react";
import { Play, Pause, RotateCcw } from "lucide-react";
import { fmt, GROUNDING } from "../data/constants";

export function PomodoroTimer({ taskName }) {
  const WORK_S = 25 * 60, BREAK_S = 5 * 60;
  const [secs, setSecs] = useState(WORK_S);
  const [running, setRunning] = useState(false);
  const [phase, setPhase] = useState("work");
  const [tomatoes, setTomatoes] = useState(0);
  const ref = useRef(null);

  useEffect(() => {
    if (!running) return;
    ref.current = setInterval(() => {
      setSecs((s) => {
        if (s > 1) return s - 1;
        clearInterval(ref.current);
        setRunning(false);
        if (phase === "work") { setTomatoes((c) => c + 1); setPhase("break"); return BREAK_S; }
        setPhase("work"); return WORK_S;
      });
    }, 1000);
    return () => clearInterval(ref.current);
  }, [running, phase]);

  const reset = () => { clearInterval(ref.current); setRunning(false); setPhase("work"); setSecs(WORK_S); };
  const total = phase === "work" ? WORK_S : BREAK_S;
  const pct = ((total - secs) / total) * 100;
  const R = 52, C = 2 * Math.PI * R;

  return (
    <div className="bg-white rounded-2xl p-4 shadow-sm">
      <div className="flex items-center justify-between mb-3">
        <div>
          <p className={`text-xs font-black uppercase tracking-widest ${phase === "work" ? "text-blue-500" : "text-emerald-500"}`}>
            {phase === "work" ? "🎯 Focus Session" : "☕ Rest Break"}
          </p>
          {taskName && <p className="text-[11px] text-gray-400 font-semibold mt-0.5 max-w-[170px] truncate">{taskName}</p>}
        </div>
        {tomatoes > 0 && <span className="bg-red-50 text-red-500 font-black text-xs px-2.5 py-1 rounded-full">🍅 {tomatoes}</span>}
      </div>

      <div className="relative w-32 h-32 mx-auto mb-4">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
          <circle cx="60" cy="60" r={R} fill="none" stroke="#f3f4f6" strokeWidth="8" />
          <circle
            cx="60" cy="60" r={R} fill="none"
            stroke={phase === "work" ? "#60a5fa" : "#34d399"}
            strokeWidth="8" strokeLinecap="round"
            strokeDasharray={C} strokeDashoffset={C * (1 - pct / 100)}
            style={{ transition: "stroke-dashoffset 1s linear" }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-3xl font-black text-gray-800 tabular-nums">{fmt(secs)}</span>
          <span className="text-[10px] text-gray-400 font-bold">{phase === "work" ? "stay focused" : "you earned it"}</span>
        </div>
      </div>

      <div className="flex justify-center gap-2">
        <button
          onClick={() => setRunning((r) => !r)}
          className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-black text-sm transition-all ${
            running ? "bg-gray-100 text-gray-600" : "bg-blue-500 text-white shadow-lg shadow-blue-200"
          }`}
        >
          {running ? <Pause size={14} /> : <Play size={14} />}
          {running ? "Pause" : "Start Focus"}
        </button>
        <button onClick={reset} className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center text-gray-400 hover:bg-gray-200 transition-colors">
          <RotateCcw size={14} />
        </button>
      </div>
    </div>
  );
}

export function BoxBreathing({ onClose }) {
  const PHASES = ["Inhale", "Hold", "Exhale", "Hold"];
  const COLORS = ["text-blue-500", "text-violet-500", "text-emerald-500", "text-amber-500"];
  const [phase, setPhase] = useState(0);
  const [count, setCount] = useState(4);
  const [cycles, setCycles] = useState(0);
  const [active, setActive] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    if (!active || cycles >= 4) { clearInterval(ref.current); if (cycles >= 4) setActive(false); return; }
    ref.current = setInterval(() => {
      setCount((c) => {
        if (c > 1) return c - 1;
        setPhase((p) => { const n = (p + 1) % 4; if (n === 0) setCycles((cy) => cy + 1); return n; });
        return 4;
      });
    }, 1000);
    return () => clearInterval(ref.current);
  }, [active, cycles]);

  const scaleVal = phase === 0 || phase === 2 ? 1 + (4 - count) * 0.04 : 1;

  return (
    <div className="bg-blue-50 border border-blue-100 rounded-2xl p-4">
      <div className="flex items-center justify-between mb-3">
        <p className="text-blue-700 font-black text-[11px] uppercase tracking-widest">📦 Box Breathing 4-4-4-4</p>
        <button onClick={onClose} className="text-gray-400 font-black text-sm">✕</button>
      </div>
      <div className="text-center py-2">
        <div
          className="w-20 h-20 mx-auto rounded-2xl bg-white border-4 border-blue-200 flex items-center justify-center mb-3 transition-transform duration-700"
          style={{ transform: `scale(${scaleVal})` }}
        >
          <span className={`text-3xl font-black ${COLORS[phase]}`}>{count}</span>
        </div>
        <p className={`text-lg font-black ${COLORS[phase]} mb-1`}>{PHASES[phase]}</p>
        <p className="text-xs text-gray-400 font-semibold">{cycles}/4 cycles {cycles >= 4 && "✓ Complete"}</p>
      </div>
      <button
        onClick={() => { if (cycles >= 4) { setCycles(0); setPhase(0); setCount(4); } setActive((a) => !a); }}
        className={`w-full py-2.5 rounded-xl font-black text-sm mt-2 transition-all ${
          active ? "bg-gray-100 text-gray-600" : "bg-blue-500 text-white shadow-md shadow-blue-200"
        }`}
      >
        {active ? "Pause" : cycles >= 4 ? "Restart" : "Start"}
      </button>
    </div>
  );
}

export function Grounding({ onClose }) {
  const [step, setStep] = useState(0);
  const [inputs, setInputs] = useState(Array(5).fill(""));
  const g = GROUNDING[step];

  const setInput = (val) => { const a = [...inputs]; a[step] = val; setInputs(a); };

  return (
    <div className="bg-violet-50 border border-violet-100 rounded-2xl p-4">
      <div className="flex items-center justify-between mb-3">
        <p className="text-violet-700 font-black text-[11px] uppercase tracking-widest">🌿 5-4-3-2-1 Grounding</p>
        <button onClick={onClose} className="text-violet-400 font-black text-sm">✕</button>
      </div>
      <div className="flex gap-1 mb-4">
        {GROUNDING.map((_, i) => (
          <div key={i} className={`flex-1 h-1.5 rounded-full transition-all ${i <= step ? "bg-violet-400" : "bg-violet-200"}`} />
        ))}
      </div>
      <div className="text-center mb-3">
        <span className="text-4xl block mb-2">{g.emoji}</span>
        <p className="text-violet-700 font-black text-sm">{g.prompt}</p>
      </div>
      <textarea
        value={inputs[step]} onChange={(e) => setInput(e.target.value)}
        placeholder="Type here..." rows={2}
        className="w-full bg-white rounded-xl p-3 text-sm font-semibold text-gray-700 resize-none outline-none border border-violet-100"
      />
      <div className="flex gap-2 mt-2">
        {step > 0 && <button onClick={() => setStep((s) => s - 1)} className="flex-1 py-2 bg-violet-100 text-violet-600 font-black text-sm rounded-xl">← Back</button>}
        {step < 4
          ? <button onClick={() => setStep((s) => s + 1)} className="flex-1 py-2 bg-violet-500 text-white font-black text-sm rounded-xl">Next →</button>
          : <button onClick={onClose} className="flex-1 py-2 bg-emerald-500 text-white font-black text-sm rounded-xl">✓ I feel grounded</button>}
      </div>
    </div>
  );
}
