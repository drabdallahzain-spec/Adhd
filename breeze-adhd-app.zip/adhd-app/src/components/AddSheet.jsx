import { useState } from "react";
import { Plus, Check } from "lucide-react";
import { SUGGESTIONS, DIFF } from "../data/constants";

export default function AddSheet({ addedSet, onAdd, onClose }) {
  const [cat, setCat] = useState("Self-care");
  const tabs = Object.keys(SUGGESTIONS);

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end" style={{ maxWidth: "384px", margin: "0 auto", left: 0, right: 0 }}>
      <div className="absolute inset-0 bg-black/25 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-gray-50 rounded-t-3xl shadow-2xl flex flex-col z-10" style={{ maxHeight: "78vh" }}>
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1.5 bg-gray-200 rounded-full" />
        </div>
        <div className="bg-white mx-3 rounded-2xl shadow-sm p-4 mb-2">
          <div className="flex items-center justify-between">
            <p className="font-black text-gray-800">Add a task</p>
            <button onClick={onClose} className="bg-gray-100 text-gray-500 text-[11px] font-black rounded-full px-3 py-1.5">Close</button>
          </div>
          <p className="text-gray-400 text-[11px] font-semibold mt-1">Tasks with time estimates help with ADHD time blindness.</p>
        </div>
        <div className="flex border-b border-gray-100 bg-white px-3">
          {tabs.map((t) => (
            <button
              key={t} onClick={() => setCat(t)}
              className={`flex-1 text-[10px] font-black py-2.5 border-b-2 transition-all ${cat === t ? "border-blue-400 text-blue-500" : "border-transparent text-gray-400"}`}
            >
              {t}
            </button>
          ))}
        </div>
        <div className="overflow-y-auto flex-1 p-3 space-y-2">
          {SUGGESTIONS[cat].map((item) => {
            const added = addedSet.has(item.text);
            const d = DIFF[item.difficulty];
            return (
              <button
                key={item.text} onClick={() => !added && onAdd(item)} disabled={added}
                className={`w-full bg-white rounded-2xl px-4 py-3 flex items-center gap-3 shadow-sm text-left transition-all ${
                  added ? "opacity-40 cursor-default" : "hover:shadow-md active:scale-[0.98]"
                }`}
              >
                <span className="text-xl flex-shrink-0">{item.emoji}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${d.bg} ${d.color}`}>{d.label}</span>
                    <span className="text-[10px] text-gray-400 font-bold">~{item.timeMin}m</span>
                  </div>
                  <span className="font-bold text-gray-800 text-sm">{item.text}</span>
                </div>
                {added ? <Check size={13} className="text-emerald-400 flex-shrink-0" /> : <Plus size={13} className="text-gray-300 flex-shrink-0" />}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
