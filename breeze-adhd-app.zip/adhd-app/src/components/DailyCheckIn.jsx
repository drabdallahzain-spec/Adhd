import { useState } from "react";
import { ENERGY_LEVELS, HALT } from "../data/constants";

export function EnergySelector({ energy, onChange }) {
  return (
    <div className="bg-white rounded-2xl p-3.5 shadow-sm">
      <p className="text-[11px] font-black text-gray-400 uppercase tracking-widest mb-2.5">🧠 How's your brain right now?</p>
      <div className="grid grid-cols-4 gap-1.5">
        {ENERGY_LEVELS.map((e) => (
          <button
            key={e.id} onClick={() => onChange(e.id)}
            className={`flex flex-col items-center gap-1 rounded-xl py-2.5 border-2 transition-all ${
              energy === e.id ? `${e.border} ${e.bg} ${e.text}` : "border-gray-100 text-gray-400"
            }`}
          >
            <span className="text-xl">{e.emoji}</span>
            <span className="text-[10px] font-black leading-tight">{e.label}</span>
          </button>
        ))}
      </div>
      {energy && (
        <p className="mt-2.5 text-xs text-gray-500 font-semibold text-center italic">
          "{ENERGY_LEVELS.find((e) => e.id === energy)?.desc}"
        </p>
      )}
    </div>
  );
}

export function HALTBanner({ onAddTask }) {
  const [ticked, setTicked] = useState({});
  const [gone, setGone] = useState(false);
  if (gone) return null;

  return (
    <div className="bg-amber-50 border border-amber-100 rounded-2xl p-3.5">
      <div className="flex items-center justify-between mb-1.5">
        <p className="text-amber-700 font-black text-[11px] uppercase tracking-widest">⚡ HALT Check-In</p>
        <button onClick={() => setGone(true)} className="text-amber-400 font-black text-xs">✕</button>
      </div>
      <p className="text-gray-500 text-[11px] font-semibold mb-2.5">Before tasks — check your basic needs:</p>
      <div className="grid grid-cols-2 gap-1.5">
        {HALT.map((h) => (
          <button
            key={h.id}
            onClick={() => { if (!ticked[h.id]) { onAddTask(h.task); setTicked((c) => ({ ...c, [h.id]: true })); } }}
            className={`flex items-center gap-2 rounded-xl px-2.5 py-2 border transition-all text-left ${
              ticked[h.id] ? "border-amber-300 bg-amber-100" : "border-transparent bg-white"
            }`}
          >
            <span className="text-base">{h.emoji}</span>
            <div>
              <p className="text-[11px] font-black text-gray-700">{h.label}</p>
              {ticked[h.id] && <p className="text-[10px] text-amber-600 font-semibold">{h.fix}</p>}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
