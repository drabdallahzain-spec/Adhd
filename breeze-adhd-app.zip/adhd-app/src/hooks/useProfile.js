import { useCallback, useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";

export function useProfile(userId) {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!userId) return;
    const { data, error } = await supabase
      .from("profiles")
      .select("xp, current_streak, longest_streak, last_active_date")
      .eq("id", userId)
      .single();
    if (!error) setProfile(data);
    setLoading(false);
  }, [userId]);

  useEffect(() => { load(); }, [load]);

  // Calls the award_xp() Postgres function, which also advances the
  // daily streak atomically on the server (see supabase/schema.sql).
  const awardXp = useCallback(async (amount) => {
    const { data, error } = await supabase.rpc("award_xp", { p_amount: amount });
    if (!error && data?.[0]) setProfile((p) => ({ ...p, ...data[0] }));
    return { data, error };
  }, []);

  return { profile, loading, awardXp, reload: load };
}
