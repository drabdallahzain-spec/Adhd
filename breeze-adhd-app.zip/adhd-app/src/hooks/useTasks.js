import { useCallback, useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";

const XP_MAP = { easy: 10, medium: 20, hard: 35 };

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

// Maps a DB row (snake_case) to the shape the UI components expect.
function fromRow(row, done) {
  return {
    id: row.id,
    category: row.category,
    emoji: row.emoji,
    text: row.text,
    timeMin: row.time_min,
    difficulty: row.difficulty,
    energyNeeded: row.energy_needed,
    habitStack: row.habit_stack,
    done,
  };
}

export function useTasks(userId, onComplete) {
  const [templates, setTemplates] = useState([]);
  const [completedIds, setCompletedIds] = useState(new Set());
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!userId) return;
    setLoading(true);

    // No-op after the first successful seed for this user.
    await supabase.rpc("seed_default_tasks");

    const [{ data: tpl, error: tplErr }, { data: done, error: doneErr }] = await Promise.all([
      supabase
        .from("task_templates")
        .select("*")
        .eq("user_id", userId)
        .eq("active", true)
        .order("sort_order", { ascending: true }),
      supabase
        .from("task_completions")
        .select("template_id")
        .eq("user_id", userId)
        .eq("completed_date", todayISO()),
    ]);

    if (!tplErr) setTemplates(tpl ?? []);
    if (!doneErr) setCompletedIds(new Set((done ?? []).map((d) => d.template_id)));
    setLoading(false);
  }, [userId]);

  useEffect(() => { load(); }, [load]);

  const tasks = templates.map((t) => fromRow(t, completedIds.has(t.id)));

  const toggleTask = useCallback(async (templateId) => {
    const isDone = completedIds.has(templateId);
    const template = templates.find((t) => t.id === templateId);

    if (isDone) {
      // Undo today's completion. Already-earned XP is intentionally kept —
      // clawing back rewards is demotivating and works against the
      // positive-reinforcement design this app is built around.
      setCompletedIds((prev) => { const n = new Set(prev); n.delete(templateId); return n; });
      await supabase
        .from("task_completions")
        .delete()
        .eq("user_id", userId)
        .eq("template_id", templateId)
        .eq("completed_date", todayISO());
    } else {
      setCompletedIds((prev) => new Set(prev).add(templateId));
      await supabase
        .from("task_completions")
        .insert({ user_id: userId, template_id: templateId, completed_date: todayISO() });
      onComplete?.(XP_MAP[template?.difficulty] || 10);
    }
  }, [completedIds, templates, userId, onComplete]);

  const addTask = useCallback(async (item) => {
    const { data, error } = await supabase
      .from("task_templates")
      .insert({
        user_id: userId,
        category: item.category,
        emoji: item.emoji,
        text: item.text,
        time_min: item.timeMin,
        difficulty: item.difficulty,
        energy_needed: item.energyNeeded,
        habit_stack: item.habitStack || "",
        sort_order: templates.length + 1,
      })
      .select()
      .single();
    if (!error && data) setTemplates((prev) => [...prev, data]);
    return { data, error };
  }, [templates.length, userId]);

  return { tasks, loading, toggleTask, addTask, reload: load };
}
