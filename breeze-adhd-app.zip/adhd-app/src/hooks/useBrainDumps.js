import { useCallback, useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";

export function useBrainDumps(userId) {
  const [dumps, setDumps] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!userId) return;
    const { data, error } = await supabase
      .from("brain_dumps")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: true });
    if (!error) setDumps(data ?? []);
    setLoading(false);
  }, [userId]);

  useEffect(() => { load(); }, [load]);

  const addDump = useCallback(async (content, mood) => {
    const { data, error } = await supabase
      .from("brain_dumps")
      .insert({ user_id: userId, content, mood })
      .select()
      .single();
    if (!error && data) setDumps((prev) => [...prev, data]);
    return { data, error };
  }, [userId]);

  const markConverted = useCallback(async (id) => {
    setDumps((prev) => prev.map((d) => (d.id === id ? { ...d, converted: true } : d)));
    await supabase.from("brain_dumps").update({ converted: true }).eq("id", id);
  }, []);

  return { dumps, loading, addDump, markConverted };
}
