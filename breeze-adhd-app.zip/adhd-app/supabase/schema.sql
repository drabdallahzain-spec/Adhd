-- ════════════════════════════════════════════════════════════════
--  Breeze — ADHD Daily Companion
--  Supabase schema: run this entire file once in
--  Supabase Dashboard → SQL Editor → New query → Run
-- ════════════════════════════════════════════════════════════════

-- ── 1. PROFILES ─────────────────────────────────────────────────
-- One row per user. Holds gamification state (XP / streak).
create table if not exists profiles (
  id                uuid primary key references auth.users(id) on delete cascade,
  xp                integer not null default 0,
  current_streak    integer not null default 0,
  longest_streak    integer not null default 0,
  last_active_date  date,
  created_at        timestamptz not null default now()
);

alter table profiles enable row level security;

create policy "Users manage their own profile"
  on profiles for all
  using (auth.uid() = id)
  with check (auth.uid() = id);

-- Auto-create a profile the moment someone signs up.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id) values (new.id);
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();


-- ── 2. TASK_TEMPLATES ───────────────────────────────────────────
-- A user's recurring daily checklist (incl. the 5 prayers).
create table if not exists task_templates (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null references auth.users(id) on delete cascade,
  category        text not null,
  emoji           text not null default '✅',
  text            text not null,
  time_min        integer not null default 5,
  difficulty      text not null default 'easy'
                    check (difficulty in ('easy','medium','hard')),
  energy_needed   text not null default 'low'
                    check (energy_needed in ('low','medium','high')),
  habit_stack     text default '',
  sort_order      integer not null default 0,
  active          boolean not null default true,
  created_at      timestamptz not null default now()
);

alter table task_templates enable row level security;

create policy "Users manage their own tasks"
  on task_templates for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);


-- ── 3. TASK_COMPLETIONS ─────────────────────────────────────────
-- One row = one template marked done on one date.
create table if not exists task_completions (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null references auth.users(id) on delete cascade,
  template_id     uuid not null references task_templates(id) on delete cascade,
  completed_date  date not null default current_date,
  completed_at    timestamptz not null default now(),
  unique (template_id, completed_date)
);

alter table task_completions enable row level security;

create policy "Users manage their own completions"
  on task_completions for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);


-- ── 4. BRAIN_DUMPS ──────────────────────────────────────────────
-- Free-form captured thoughts from the Dump tab.
create table if not exists brain_dumps (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references auth.users(id) on delete cascade,
  content     text not null,
  mood        text,
  converted   boolean not null default false,
  created_at  timestamptz not null default now()
);

alter table brain_dumps enable row level security;

create policy "Users manage their own brain dumps"
  on brain_dumps for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);


-- ── 5. UNLOCKED_ACHIEVEMENTS ────────────────────────────────────
create table if not exists unlocked_achievements (
  user_id         uuid not null references auth.users(id) on delete cascade,
  achievement_id  text not null,
  unlocked_at     timestamptz not null default now(),
  primary key (user_id, achievement_id)
);

alter table unlocked_achievements enable row level security;

create policy "Users manage their own achievements"
  on unlocked_achievements for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);


-- ── 6. award_xp() ───────────────────────────────────────────────
-- Atomically adds XP and advances the daily streak at most once
-- per calendar day, server-side, so it can't race or double-count.
create or replace function public.award_xp(p_amount integer)
returns table (xp integer, current_streak integer, longest_streak integer)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user    uuid := auth.uid();
  v_today   date := current_date;
  v_last    date;
  v_streak  integer;
  v_longest integer;
begin
  select last_active_date, profiles.current_streak, profiles.longest_streak
    into v_last, v_streak, v_longest
    from profiles where id = v_user;

  if v_last = v_today then
    null;                              -- already active today: XP only
  elsif v_last = v_today - 1 then
    v_streak := v_streak + 1;          -- consecutive day
  else
    v_streak := 1;                     -- streak broken or first-ever day
  end if;

  v_longest := greatest(v_longest, v_streak);

  update profiles
    set xp                = xp + p_amount,
        current_streak    = v_streak,
        longest_streak    = v_longest,
        last_active_date  = v_today
    where id = v_user;

  return query
    select profiles.xp, profiles.current_streak, profiles.longest_streak
    from profiles where id = v_user;
end;
$$;

grant execute on function public.award_xp(integer) to authenticated;


-- ── 7. seed_default_tasks() ─────────────────────────────────────
-- Populates a brand-new user's checklist, including the 5 daily
-- prayers. Safe to call repeatedly — it's a no-op after the first
-- successful seed.
create or replace function public.seed_default_tasks()
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
begin
  if exists (select 1 from task_templates where user_id = v_user) then
    return;
  end if;

  insert into task_templates
    (user_id, category, emoji, text, time_min, difficulty, energy_needed, habit_stack, sort_order)
  values
    (v_user, 'Prayer',       '🌅', 'صلاة الفجر — Fajr',                5,  'easy',   'low',    'right after waking',   1),
    (v_user, 'Prayer',       '☀️', 'صلاة الظهر — Dhuhr',               8,  'easy',   'low',    'pause work at midday', 2),
    (v_user, 'Prayer',       '🌤️','صلاة العصر — Asr',                 8,  'easy',   'low',    'mid-afternoon break',  3),
    (v_user, 'Prayer',       '🌆', 'صلاة المغرب — Maghrib',            5,  'easy',   'low',    'right at sunset',      4),
    (v_user, 'Prayer',       '🌙', 'صلاة العشاء — Isha',               10, 'easy',   'low',    'before sleep routine', 5),
    (v_user, 'Productivity', '🛏️','Make your bed',                    2,  'easy',   'low',    'right after waking',   6),
    (v_user, 'Self-care',    '🪥', 'Brush and floss your teeth',       3,  'easy',   'low',    'after breakfast',      7),
    (v_user, 'Self-care',    '💧', 'Drink a full glass of water',      1,  'easy',   'low',    'first thing you do',   8),
    (v_user, 'Productivity', '⏱️','Focus on one task for 25 minutes', 25, 'hard',   'high',   'mid-morning peak',     9),
    (v_user, 'Move',         '🏃', 'Stand up and move for 5 minutes',  5,  'easy',   'medium', 'every 90 minutes',     10),
    (v_user, 'Mindfulness',  '💗', 'Write one thing that went well',   3,  'easy',   'low',    'before sleep',         11),
    (v_user, 'Self-care',    '🥣', 'Eat a proper meal',                15, 'medium', 'medium', 'midday',               12),
    (v_user, 'Calm',         '💨', 'Take 5 deep, slow breaths',        2,  'easy',   'low',    'when stressed',        13);
end;
$$;

grant execute on function public.seed_default_tasks() to authenticated;

-- ════════════════════════════════════════════════════════════════
--  Done. Next: Project Settings → API → copy the Project URL and
--  anon public key into your .env file (see .env.example).
-- ════════════════════════════════════════════════════════════════
